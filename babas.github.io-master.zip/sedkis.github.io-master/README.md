# portfolio-v2

Personal website, you can visit it at [www.sedky.ca](https://www.sedky.ca).  

It's just static JS/CSS, hosted for free using Github Pages.

To fork, simply clone it and open the [index.hmtl](./index.html) file.  You can download VS Code plugin to do live reloading for you while you do development.
